export { CreateAppointmentDto } from './create-appointment.dto';
export { UpdateAppointmentDto } from './update-appointment.dto';
export { AppointmentQueryDto } from './appointment-query.dto';
export { AvailableSlotsQueryDto } from './available-slots-query.dto';
